#!/bin/sh
mkdir m4
autoreconf -ivf
