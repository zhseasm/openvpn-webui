// hex decoder

#ifndef SRC_HEX_H_
#define SRC_HEX_H_

#include <stdint.h>

int hex_decode(const char *encoded, uint8_t *result, int bufSize);

#endif /* SRC_HEX_H_ */
